import Card from "../UI/Card";

function WorkerList(props) {
  const { workers, setWorkers } = props;
  if (workers.length < 1) {
    return;
  }
  const deleteWorker = (id) => {
    setWorkers(workers.filter((item) => item.id !== id));
  };
  return (
    <Card className="mt-10">
      <div className="">
        <ul>
          <li className="flex justify-between">
            <span className="font-bold">İsim</span>
            <span className="font-bold">Maaş</span>
          </li>
          {workers.map((worker) => (
            <li
              className="flex justify-between cursor-pointer p-2 hover:shadow-xl transitition-shadow "
              key={worker.id}
              onClick={() => deleteWorker(worker.id)}
            >
              <span> {worker.name} </span>
              <span className="text-teal-700 font-medium">{worker.wage}₺</span>
            </li>
          ))}
        </ul>
      </div>
    </Card>
  );
}

export default WorkerList;
